var REQUEST_GET_INSTALLED_EDITORS = "Request::GetInstalledEditors";
var RESPONSE_GET_INSTALLED_EDITORS = "Response::GetInstalledEditors";

var CDN_JS_ACE_ROOT = 'https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.6/';
var CDN_JS_ACE = CDN_JS_ACE_ROOT + 'ace.js';
